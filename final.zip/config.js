// ============================================
// ADVENTO CONFIG — Supabase Connection
// ============================================
const SUPABASE_URL = 'https://tyycbnbfnlekxngozvsj.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR5eWNibmJmbmxla3huZ296dnNqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI3MTEzNzIsImV4cCI6MjA5ODI4NzM3Mn0.KmZdiAq3GkdCEnk_Xv4kkWvtsIhSENPNgvcgfaUXueI';
